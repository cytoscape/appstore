import { AdjacencyMap, MCODECluster, MCODEParameters, NodeInfo } from './mcodeTypes';
/**
 * Structured-cloneable snapshot of a scored algorithm's state. Used to carry
 * the algorithm out of the web worker (which can't transfer a class instance)
 * and rehydrate it on the main thread — see toSnapshot()/fromSnapshot().
 */
export interface MCODEAlgorithmSnapshot {
    params: MCODEParameters;
    adjacency: AdjacencyMap;
    nodeInfo: Map<string, NodeInfo>;
    nodesByScoreDesc: string[];
}
export declare class MCODEAlgorithm {
    private readonly params;
    /** The adjacency the graph was scored from; retained so the scored state can
     *  be snapshotted and rehydrated (the graph is rebuilt from it). */
    private adjacency;
    /** Full input network as an MCODEGraph. Set during scoreGraph(). */
    private graph;
    /** Per-node cached metrics (density, k-core, score), keyed by node id. */
    private nodeInfo;
    /** Node ids ordered by descending score (seed iteration order). */
    private nodesByScoreDesc;
    constructor(params?: Partial<MCODEParameters>);
    /**
     * Convenience entry point: score the graph and return ranked clusters.
     * `adjacency` is an undirected `nodeId -> neighborIds` map (e.g. built from
     * Cytoscape Web's ElementApi.getConnectedNodes).
     */
    run(adjacency: AdjacencyMap): MCODECluster[];
    /**
     * Compute a NodeInfo (and score) for every node. Equivalent to the Java
     * scoreGraph()/calcNodeInfo()/scoreNode() trio; runs sequentially here.
     */
    scoreGraph(adjacency: AdjacencyMap): void;
    /**
     * Per-node metrics: neighborhood density and the density of the
     * neighborhood's highest k-core. Mirrors calcNodeInfo().
     */
    private calcNodeInfo;
    /** Node score = coreDensity * coreLevel, or 0 below the degree cutoff. */
    private scoreNode;
    /**
     * Grow clusters from seed nodes in descending score order, then filter,
     * haircut and fluff. Mirrors findClusters().
     */
    findClusters(): MCODECluster[];
    /**
     * Re-grow a single cluster from its seed using a different node-score cutoff,
     * reusing the cached node scoring (no rescoring). Mirrors the Java
     * exploreCluster(): unlike findClusters there is NO k-core filter, so the
     * cluster can shrink all the way to a single node.
     *
     * Returns a NEW cluster (the input is not mutated). `seedId` and `rank` are
     * preserved; `nodes` and `score` are recomputed; `nodePositions` is left unset
     * so the caller's thumbnail regenerates its layout. Because it re-expands from
     * the seed (not from the cluster's current nodes), it is idempotent for a
     * given cutoff.
     */
    exploreCluster(cluster: MCODECluster, nodeScoreCutoff: number): MCODECluster;
    /**
     * Build the list of nodes forming a cluster core grown from `seedId`.
     * Mirrors getClusterCore(): the seed is included, then neighbors are added
     * recursively when their score clears the seed-relative threshold.
     */
    private getClusterCore;
    /**
     * Recursive neighbor expansion. Mirrors getClusterCoreInternal().
     * `seedScore` is the reference score of the original seed and stays constant
     * across the recursion; a neighbor qualifies when
     *   score(neighbor) >= seedScore * (1 - nodeScoreCutoff).
     */
    private getClusterCoreInternal;
    /**
     * Returns true when the cluster should be discarded: it must contain a
     * non-empty k-core of size `params.kCore`. Mirrors filterCluster().
     */
    private filterCluster;
    /**
     * Haircut: reduce the cluster to its 2-core, removing degree-1 pendant
     * nodes. Falls back to the original nodes if no 2-core exists.
     * Mirrors haircutCluster().
     */
    private haircutCluster;
    /**
     * Fluff: add neighbors of the cluster whose own neighborhood density exceeds
     * `fluffNodeDensityCutoff`. Fluffed nodes are NOT added to the global
     * nodeSeen set, so they may also appear in other clusters.
     * Mirrors fluffClusterBoundary().
     */
    private fluffCluster;
    /** Cluster score = density * nodeCount. Mirrors scoreCluster(). */
    private scoreCluster;
    /** Sort clusters by descending score and assign 1-based ranks. */
    private rank;
    /** The parameters this algorithm was configured with. */
    getParameters(): MCODEParameters;
    /** Score assigned to a node during scoreGraph(); 0 if the node is unknown. */
    getNodeScore(nodeId: string): number;
    /** Cached metrics for a node, or undefined if it was never scored. */
    getNodeInfo(nodeId: string): NodeInfo | undefined;
    /** Every scored node's score, keyed by node id. */
    getScores(): Record<string, number>;
    /**
     * Capture the scored state into a structured-cloneable snapshot, so the
     * algorithm can be transferred out of the web worker. Rehydrate it on the
     * main thread with fromSnapshot().
     */
    toSnapshot(): MCODEAlgorithmSnapshot;
    /**
     * Reconstruct an algorithm from a snapshot. The graph is rebuilt from the
     * adjacency, and the cached node metrics + seed order are restored as-is, so
     * findClusters() (and future cluster-exploration) can run again without
     * recomputing the expensive per-node scoring.
     */
    static fromSnapshot(snapshot: MCODEAlgorithmSnapshot): MCODEAlgorithm;
    private scoreOf;
    private requireGraph;
}
