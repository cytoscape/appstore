import { MCODEAlgorithm } from './mcodeAlgorithm';
import { AdjacencyMap, MCODECluster, MCODEParameters } from './mcodeTypes';
/** Rejection raised when an in-flight analysis is cancelled by the user. */
export declare class McodeCancelledError extends Error {
    constructor();
}
/** Result of a successful analysis: ranked clusters plus the (rehydrated)
 *  algorithm instance carrying the cached scoring state. */
export interface MCODEAnalysisResult {
    clusters: MCODECluster[];
    algorithm: MCODEAlgorithm;
}
export interface McodeWorkerController {
    run: (adjacency: AdjacencyMap, parameters: MCODEParameters) => Promise<MCODEAnalysisResult>;
    cancel: () => void;
}
export declare function useMcodeWorker(): McodeWorkerController;
