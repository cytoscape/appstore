import { MCODECluster, MCODEResult } from './mcodeTypes';
export interface McodeResultActions {
    /** Make the result's source network the active/shown one. */
    viewSourceNetwork: () => void;
    /** Apply the MCODE visual style to the result's source network. */
    applyMcodeStyle: () => void;
    /** Create a new subnetwork from the selected cluster. */
    createClusterNetwork: () => void;
    /** Download the selected result as a tab-delimited .txt report. */
    exportResult: () => void;
}
export declare function useMcodeResultActions(selectedResult: MCODEResult | null, selectedCluster: MCODECluster | null): McodeResultActions;
