/**
 * Pure helpers for turning MCODE results into external representations:
 *   - a tab-delimited results report (.txt), mirroring the Java exporter, and
 *   - a cluster subnetwork sliced out of the source network's CX2.
 *
 * These have no React or Cytoscape Web dependencies (they operate on plain
 * data), so they are straightforward to unit-test in isolation.
 */
import type { ValueType, ValueTypeName } from '@cytoscape-web/api-types';
import { MCODECluster, MCODEParameters } from './mcodeTypes';
/**
 * Score formatted with up to 3 fraction digits, trailing zeros stripped
 * (matches the Java NumberFormat with maximumFractionDigits = 3): e.g.
 * 2.3333 -> "2.333", 2 -> "2", 1.6 -> "1.6".
 */
export declare function formatScore(score: number): string;
/** Per-cluster values needed to render one row of the export report. */
export interface ClusterExportRow {
    score: number;
    nodeCount: number;
    edgeCount: number;
    /** Display names of the cluster's nodes, in order. */
    nodeNames: string[];
}
/**
 * Build the MCODE results report text. The cluster rank is the row's 1-based
 * position in `rows` (which are expected to already be in ranked order).
 *
 * `now` is injectable so the output is deterministic in tests.
 */
export declare function buildMcodeResultsText(parameters: MCODEParameters, rows: ClusterExportRow[], now?: Date): string;
/**
 * Slice a source network's CX2 stream down to a single cluster: keep only the
 * cluster's nodes (with coordinates overridden from `nodePositions` when
 * present, so the importer runs no layout) and the edges whose endpoints are
 * both in the cluster, and fix up the metaData element counts to match.
 *
 * Operates on the loosely-typed CX2 aspect array (`any[]`); the caller casts
 * the result to the cyweb `Cx2` type when handing it to createNetworkFromCx2.
 */
export declare function sliceClusterCx2(cx2: any[], clusterNodeIds: string[], nodePositions?: Record<string, {
    x: number;
    y: number;
}>): any[];
/** Namespace prefixing every MCODE node-table column. */
export declare const MCODE_NAMESPACE = "MCODE";
/** The per-result node attributes MCODE writes to the source network. */
export type McodeNodeAttr = 'Score' | 'Node Status' | 'Clusters';
/**
 * Column name for an MCODE node attribute and result number, e.g.
 * `mcodeColumnName('Score', 1)` -> "MCODE::Score (1)". Mirrors the Java
 * `MCODEUtil.columnName(name, result)`.
 */
export declare function mcodeColumnName(attr: McodeNodeAttr, resultNumber: number): string;
/** The three node-table column names MCODE creates for a given result. */
export declare function mcodeColumnNames(resultNumber: number): string[];
/** A node-table column to create (name + Cytoscape Web value type + default). */
export interface NodeColumnDef {
    name: string;
    type: ValueTypeName;
    defaultValue: ValueType;
}
export interface McodeNodeTableData {
    /** Columns to create on the source network's node table. */
    columns: NodeColumnDef[];
    /** Node-id -> { columnName -> value } edits to apply. */
    rows: Record<string, Record<string, ValueType>>;
}
/**
 * Build the node-table columns and row values for an MCODE result, mirroring
 * `MCODEAnalyzeTask.createNetworkAttributes()`:
 *   - "MCODE::Score (n)"       (double)          : the node's MCODE score
 *   - "MCODE::Node Status (n)" (string)          : Unclustered | Clustered | Seed
 *   - "MCODE::Clusters (n)"    (list of string)  : e.g. ["Cluster 1", "Cluster 3"]
 *
 * Every scored node gets its score and defaults to "Unclustered"; nodes that
 * belong to clusters accumulate the cluster names and are marked "Seed" (when
 * the cluster's seed) or "Clustered". Nodes not analyzed simply keep the
 * column defaults.
 */
export declare function buildMcodeNodeTableData(resultNumber: number, clusters: MCODECluster[], scores: Record<string, number>): McodeNodeTableData;
