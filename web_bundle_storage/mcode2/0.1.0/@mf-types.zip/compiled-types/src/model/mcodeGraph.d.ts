/**
 * MCODEGraph — a lightweight, immutable undirected graph used by the MCODE
 * algorithm for neighborhood, cluster and k-core computations.
 *
 * TypeScript port of the graph helpers from BaderLab/MCODE (LGPL v2.1+).
 * See mcodeTypes.ts for full attribution.
 *
 * The graph stores an adjacency map restricted to its own node set, so that
 * induced subgraphs (neighborhoods, k-cores, clusters) can be derived cheaply
 * without referencing the parent network. Edges are treated as undirected and
 * parallel/duplicate edges are merged (each unordered node pair counts once).
 */
import { AdjacencyMap } from './mcodeTypes';
export declare class MCODEGraph {
    /** Node ids contained in this graph. */
    readonly nodes: string[];
    private readonly nodeSet;
    /** Adjacency restricted to `nodeSet`; values are de-duplicated. */
    private readonly adjacency;
    /**
     * Build an induced subgraph over `nodeIds` using the supplied adjacency.
     * Any neighbor not in `nodeIds` is dropped, so the result is self-contained.
     */
    constructor(nodeIds: Iterable<string>, sourceAdjacency: AdjacencyMap);
    get nodeCount(): number;
    /** Neighbors of `nodeId` within this graph (empty if absent). */
    neighbors(nodeId: string): string[];
    /**
     * Degree of `nodeId` = number of merged undirected edges touching it.
     * A self-loop contributes 1 only when `includeLoops` is true.
     */
    degree(nodeId: string, includeLoops: boolean): number;
    /**
     * Count of unique undirected edges in the graph. Each unordered pair is
     * counted once; self-loops are included only when `includeLoops` is true.
     */
    edgeCount(includeLoops: boolean): number;
    /**
     * Graph density = actualEdges / possibleEdges.
     *
     *   possibleEdges = includeLoops ? n*(n+1)/2 : n*(n-1)/2
     *
     * Returns 0 when there are too few nodes to form any edge.
     */
    density(includeLoops: boolean): number;
    /** Build the induced subgraph over a subset of this graph's nodes. */
    subgraph(nodeIds: Iterable<string>): MCODEGraph;
    /**
     * The k-core: the maximal subgraph in which every node has degree >= k.
     * Computed by iteratively removing all nodes whose degree drops below k.
     * Returns null when the k-core is empty.
     */
    getKCore(k: number, includeLoops: boolean): MCODEGraph | null;
    /**
     * The highest k-core in the graph: the largest k for which a non-empty
     * k-core exists, together with that core's subgraph.
     * Returns `{ k: 0, graph: null }` for an edgeless graph.
     */
    getHighestKCore(includeLoops: boolean): {
        k: number;
        graph: MCODEGraph | null;
    };
}
