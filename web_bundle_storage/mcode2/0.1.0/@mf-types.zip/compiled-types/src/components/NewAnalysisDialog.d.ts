import { JSX } from 'react/jsx-runtime';
import { MCODEParameters } from '../model/mcodeTypes';
export declare const NewAnalysisDialog: ({ networkId, open, onClose, onSubmit, }: {
    networkId: string;
    open: boolean;
    onClose: () => void;
    onSubmit: (parameters: MCODEParameters) => void;
}) => JSX.Element;
export default NewAnalysisDialog;
