import { JSX } from 'react/jsx-runtime';
declare const MCODEPanel: () => JSX.Element;
export default MCODEPanel;
